
Enterprise Phishing Detector - Full Project (Production-style)

Structure:
 - backend/: Flask API + model + worker + queue + logs
 - frontend/: Professional dashboard (static)

Run instructions: see backend/README.md (use Python 3.10)
