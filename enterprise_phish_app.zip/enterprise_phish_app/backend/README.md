
Enterprise Phishing Detector - Backend

Run (CMD) steps (Windows) - Python 3.10 recommended:

cd path\to\enterprise_phish_app\backend
python -m venv venv
venv\Scripts\activate
python -m pip install -r requirements.txt

# Optional: retrain model (takes ~minutes)
python train_model.py

# Start worker (in separate CMD window)
python worker.py

# Start API (in separate CMD window)
python app.py

Open browser and go to http://127.0.0.1:5000 (frontend served by Flask)
