
import os, json
QUEUE_FILE = os.path.join(os.path.dirname(__file__), 'queue.jsonl')

def enqueue(url):
    os.makedirs(os.path.dirname(QUEUE_FILE), exist_ok=True)
    with open(QUEUE_FILE, 'a') as f:
        f.write(json.dumps({'url': url}) + '\\n')
