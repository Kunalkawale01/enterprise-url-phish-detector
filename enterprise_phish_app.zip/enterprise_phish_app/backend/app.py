
from flask import Flask, request, jsonify, send_from_directory
import os, pickle, time
from utils.feature_extractor import extract_features
from queue_utils import enqueue

BASE_DIR = os.path.dirname(__file__)
MODEL_PATH = os.path.join(BASE_DIR, 'model', 'model.pkl')

app = Flask(__name__, static_folder='../frontend', static_url_path='/frontend')

def load_model():
    if os.path.exists(MODEL_PATH):
        with open(MODEL_PATH, 'rb') as f:
            return pickle.load(f)
    return None

MODEL = load_model()

@app.route('/')
def root():
    return send_from_directory('../frontend', 'index.html')

@app.route('/api/predict', methods=['POST'])
def predict():
    data = request.get_json() or {}
    url = data.get('url','')
    if not url:
        return jsonify({'error':'no url provided'}), 400
    # enqueue job for background processing (persisted queue)
    enqueue(url)
    # immediate lightweight features + model-based prediction if model available
    features = extract_features(url)
    response = {'url': url, 'features': features, 'queued': True, 'timestamp': time.time()}
    if MODEL:
        feat_order = MODEL.get('feature_order') or sorted(features.keys())
        X = [[features.get(k,0) for k in feat_order]]
        model = MODEL['model']
        pred = int(model.predict(X)[0])
        prob = float(model.predict_proba(X)[0][1]) if hasattr(model, 'predict_proba') else None
        response.update({'is_phishing': bool(pred==1), 'model_score': prob})
    return jsonify(response)

@app.route('/frontend/<path:filename>')
def frontend_files(filename):
    return send_from_directory('../frontend', filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
