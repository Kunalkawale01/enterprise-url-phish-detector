
import time, json, os
from utils.feature_extractor import extract_features

QUEUE_FILE = os.path.join(os.path.dirname(__file__), 'queue.jsonl')
LOG_FILE = os.path.join(os.path.dirname(__file__), 'logs', 'scan_log.jsonl')

def process_job(job):
    url = job.get('url')
    features = extract_features(url)
    # simple rule-based score (for immediate availability)
    score = 0.0
    score += min(features['count_dots'] / 10.0, 0.4)
    score += 0.3 if features['has_ip'] else 0.0
    score += 0.2 if features['count_hyphen'] > 2 else 0.0
    score += 0.1 if not features['uses_https'] else 0.0
    score = min(score, 1.0)
    result = {
        'url': url,
        'features': features,
        'risk_score': score,
        'timestamp': time.time()
    }
    return result

def worker_loop():
    print("Worker started, watching queue:", QUEUE_FILE)
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    while True:
        if os.path.exists(QUEUE_FILE):
            with open(QUEUE_FILE, 'r') as f:
                lines = f.read().strip().splitlines()
            if lines:
                remaining = []
                for line in lines:
                    try:
                        job = json.loads(line)
                        res = process_job(job)
                        with open(LOG_FILE, 'a') as lf:
                            lf.write(json.dumps(res) + '\\n')
                        print("Processed:", job.get('url'))
                    except Exception as e:
                        print("Job processing error:", e)
                        remaining.append(line)
                # clear queue file after processing
                open(QUEUE_FILE, 'w').close()
        time.sleep(1)

if __name__ == '__main__':
    worker_loop()
