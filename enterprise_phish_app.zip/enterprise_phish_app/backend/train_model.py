
import os, pickle, random, string
from utils.feature_extractor import extract_features
from sklearn.ensemble import RandomForestClassifier

def make_synthetic(n=3000):
    X, y = [], []
    for _ in range(n):
        if random.random() > 0.6:
            host = "www." + ''.join(random.choices(string.ascii_lowercase, k=random.randint(5,12))) + ".com"
            url = "https://" + host + "/"
            label = 0
        else:
            if random.random() < 0.2:
                host = ".".join(str(random.randint(1,255)) for _ in range(4))
                url = "http://" + host + "/" + ''.join(random.choices(string.ascii_letters+string.digits, k=8))
            else:
                host = ''.join(random.choices(string.ascii_lowercase+string.digits+'-', k=random.randint(8,18)))
                url = "http://" + host + ".ru/login?user=" + ''.join(random.choices(string.ascii_letters, k=6))
            label = 1
        f = extract_features(url)
        X.append([f[k] for k in sorted(f.keys())])
        y.append(label)
    return X, y

def train_and_save(out='model/model.pkl'):
    os.makedirs(os.path.dirname(out), exist_ok=True)
    X, y = make_synthetic(3000)
    clf = RandomForestClassifier(n_estimators=150, random_state=42)
    clf.fit(X, y)
    feat_order = sorted(['count_dots','count_hyphen','has_at','has_ip','length','subdomain_depth','uses_https'])
    with open(out, 'wb') as f:
        pickle.dump({'model': clf, 'feature_order': feat_order}, f)
    print("Saved model to", out)

if __name__ == '__main__':
    train_and_save()
