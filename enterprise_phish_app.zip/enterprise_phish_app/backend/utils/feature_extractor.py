
import re
from urllib.parse import urlparse

def extract_features(url: str) -> dict:
    u = (url or "").strip()
    features = {}
    features['length'] = len(u)
    features['count_dots'] = u.count('.')
    features['count_hyphen'] = u.count('-')
    features['has_at'] = int('@' in u)
    features['has_ip'] = int(bool(re.search(r'\b\d{1,3}(?:\.\d{1,3}){3}\b', u)))
    features['uses_https'] = int(u.startswith('https'))
    try:
        hostname = urlparse(u).hostname or ''
        features['subdomain_depth'] = hostname.count('.') if hostname else 0
    except:
        features['subdomain_depth'] = 0
    return features
